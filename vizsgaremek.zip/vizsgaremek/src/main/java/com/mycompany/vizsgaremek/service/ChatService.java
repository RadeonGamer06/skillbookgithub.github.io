/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vizsgaremek.service;


import com.mycompany.vizsgaremek.model.ChatMessage;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.time.LocalDateTime;
import java.io.*;
import java.nio.file.*;
import java.util.UUID;

@Stateless
public class ChatService {

    private static final String UPLOAD_FOLDER = 
        "C:\\Users\\Bagoly Donát\\Desktop\\SkillBook\\server\\wildfly-preview-26.1.1.Final\\standalone\\data\\uploads\\uploadedphotosthroughchat";

    @PersistenceContext
    private EntityManager em;

    // Kép feltöltése és URL visszaadása
    public String uploadImage(InputStream fileStream, String originalFileName) throws IOException {
        // Mappa létrehozása ha nem létezik
        Path uploadPath = Paths.get(UPLOAD_FOLDER);
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        String extension = getFileExtension(originalFileName);
        String newFileName = UUID.randomUUID().toString() + extension;

        Path targetPath = uploadPath.resolve(newFileName);

        try (OutputStream out = Files.newOutputStream(targetPath)) {
            byte[] buffer = new byte[8192];
            int bytesRead;
            while ((bytesRead = fileStream.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        }

        // Relatív URL a frontend számára (a WildFly-nak statikusan kell kiszolgálnia)
        return "/uploads/uploadedphotosthroughchat/" + newFileName;
    }

    // Üzenet mentése (szöveg vagy kép)
    public ChatMessage sendMessage(Long senderId, Long receiverId, String content, String imageUrl) {
        ChatMessage msg = new ChatMessage();
        msg.setSenderId(senderId);
        msg.setReceiverId(receiverId);
        msg.setContent(content);
        msg.setImageUrl(imageUrl);
        msg.setSentAt(LocalDateTime.now());

        em.persist(msg);
        return msg;
    }

    private String getFileExtension(String fileName) {
        if (fileName == null || !fileName.contains(".")) return ".jpg";
        String ext = fileName.substring(fileName.lastIndexOf(".")).toLowerCase();
        if (ext.matches("\\.(jpg|jpeg|png|gif|webp)$")) return ext;
        return ".jpg";
    }
}