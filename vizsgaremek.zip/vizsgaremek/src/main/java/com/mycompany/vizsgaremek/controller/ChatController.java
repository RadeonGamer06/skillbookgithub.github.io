/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vizsgaremek.controller;


import com.mycompany.vizsgaremek.security.MessageDTO;
import com.mycompany.vizsgaremek.model.ChatMessage;
import com.mycompany.vizsgaremek.service.ChatService;
import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Part;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import java.io.InputStream;

@Path("/chat")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ChatController {

    @EJB
    private ChatService chatService;

    // ====================== KÉP FELTÖLTÉS ======================
    @POST
    @Path("/upload-image")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    public Response uploadImage(@Context HttpServletRequest request) {
        try {
            Part filePart = request.getPart("image");

            if (filePart == null || filePart.getSize() == 0) {
                return Response.status(400).entity("{\"error\":\"Nincs fájl\"}").build();
            }

            String contentType = filePart.getContentType();
            if (contentType == null || !contentType.startsWith("image/")) {
                return Response.status(400).entity("{\"error\":\"Csak képfájl engedélyezett\"}").build();
            }

            String imageUrl = chatService.uploadImage(filePart.getInputStream(), filePart.getSubmittedFileName());

            return Response.ok("{\"imageUrl\": \"" + imageUrl + "\"}").build();

        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(500).entity("{\"error\":\"Feltöltési hiba\"}").build();
        }
    }

    // ====================== ÜZENET KÜLDÉS ======================
    @POST
    @Path("/send")
    public Response sendMessage(MessageDTO dto, @Context SecurityContext securityContext) {
        // Security: aktuális felhasználó ID-ja
        Long senderId = Long.valueOf(securityContext.getUserPrincipal().getName()); // vagy a saját módon szerzed be

        ChatMessage saved = chatService.sendMessage(
            senderId,
            dto.getReceiverId(),
            dto.getContent(),
            dto.getImageUrl()
        );

        return Response.ok(saved).build();   // vagy egyszerű {"status": "sent"}
    }
}