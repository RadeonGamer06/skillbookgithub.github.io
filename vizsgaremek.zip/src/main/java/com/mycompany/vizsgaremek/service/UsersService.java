package com.mycompany.vizsgaremek.service;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import org.json.JSONObject;
import org.mindrot.jbcrypt.BCrypt;

@Stateless
public class UsersService{
@PersistenceContext(unitName = "com.mycompany_vizsgaremek_war_1.0-SNAPSHOTPU")
    private EntityManager em;

    public JSONObject createUser(String username, String email, String password, String role) {
        JSONObject resp = new JSONObject();

        try {
            String Pw = BCrypt.hashpw(password, BCrypt.gensalt(12));

            if (role == null || role.trim().isEmpty()) {
                role = "customer";
            }

            StoredProcedureQuery query = em.createStoredProcedureQuery("createUser");

            query.registerStoredProcedureParameter("nameIN", String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("emailIN", String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("passwordIN", String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("roleIN", String.class, ParameterMode.IN);

            query.setParameter("nameIN", username);
            query.setParameter("emailIN", email);
            query.setParameter("passwordIN", Pw);
            query.setParameter("roleIN", role);

            query.execute();

            resp.put("status", "UserCreated");
            resp.put("statusCode", 201);

        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "DatabaseError");
            resp.put("statusCode", 500);
        }

        return resp;
    }}